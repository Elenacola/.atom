<?php
$contatore = 0;
$oggetto = $_POST["oggetto"];
$messaggio = $_POST["messaggio"];

$textfile = fopen("db/iscritti.txt", "r");

while ( $rigafile = fgets($textfile,1024) ) {
 $contatore = $contatore + 1;
 $campiriga = explode("|", $rigafile);
 $destinatario = $campiriga[2];
 echo "Invio email a $destinatario<br>";
 mail ($destinatario,$oggetto,$messaggio,"From: info@tuosito.com");
}

fclose($textfile);

echo "<br>Invio di <b>$contatore</b> email terminato con successo";

?> 
