<!DOCTYPE html>
<html> 
<head>
<title>News Manager</title>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4/jquery.min.js"></script>
<script type="text/javascript" src="fancybox/jquery.easing-1.3.pack.js"></script>
<script type="text/javascript" src="fancybox/jquery.mousewheel-3.0.2.pack.js"></script>
<script type="text/javascript" src="fancybox/jquery.fancybox-1.3.1.js"></script>
<link rel="stylesheet" type="text/css" href="fancybox/jquery.fancybox-1.3.1.css" media="screen" />
<style type="text/css">
<!--
td {  font-family: Arial, Helvetica, sans-serif; font-size: 13px}
h3 {  font-family: Helvetica, sans-serif; font-size: 24px; color:#FFF; padding:0; margin:0}
.top {
    margin: 0 auto; padding: 5px;width: 100%;background-color: #fff;text-align: center;column-count:4;
}
.top p {
    color:#FFF;
}
-->
</style>
    <script type="text/javascript">
        $(document).ready(function() {
            $(".link").fancybox({
                'width'             : '75%',
                'height'            : '25%',
                'autoScale'         : false,
                'transitionIn'      : 'none',
                'transitionOut'     : 'none',
                'type'              : 'iframe'
            });
            });
        </script>

</HEAD>
<body style="background-color: #CCCCCC; color: #000; margin: 0; padding: 5px">
<table style="margin: 0 auto; width: 700px">
  <tbody>
  <tr>
    <td> 
      <table class="top">
        <tbody> 
        <tr> 
          <td style="padding: 5px;background-color: #0000FF"> 
             <h3>News Manager</h3>
             <p>Il software per gestire i tuoi iscritti</p>
          </td>
        </tr>
        <tr> 
          <td></td>
        </tr>
        <tr> 
          <td bgcolor="#EAEAEA"> 
            <div align="center"><b><a href="index.htm">Home</a> | <a href="iscrizione.htm" target="_blank">Test 
              modulo Iscrizione</a> | <a href="form_invio.htm">Invia Newsletter</a> 
              | <a href="lista_iscritti.php">Elenco Iscritti</a> | <a href="2806.htm" target="_blank">Help</a></b></div>
          </td>
        </tr>
        <tr> 
          <td> <br>
            <table width="90%"  align="center" >
              <tr> 
                <td style="padding: 4px;background-color: #0000FF;text-align: center" colspan="4">
                  <div><b><font color="#FFFFFF">Elenco Iscritti</b></div>
                </td>
              </tr>
              <tr> 
                 <td><strong>ID</strong></td><td><strong>Nome</strong></td><td><strong>Email</strong></td><td></td>
              </tr>
              <tr>
<td>
<?php
$contatore = 0; 
$textfile = fopen("db/iscritti.txt", "r");
while ($rigafile = fgets($textfile,1024)) {
$campiriga = explode("|", $rigafile);
echo "<tr><td>$campiriga[0]</td><td>$campiriga[1]</td><td>$campiriga[2]</td><td><a href=\"modifica_riga.php?id=$campiriga[0]\" class=\"link\" rel=\"iframe\">Mod</a> | <a href=\"cancella_riga.php?id=$campiriga[0]\">Canc</a></td></tr>";
}

fclose($textfile);
?>
</td>
              </tr>
            </table>
            <p>&nbsp;</p>
            </td>
        </tr>
        </tbody> 
      </table>
    </td>
  </tr>
  </tbody>
</table>
<table width='700' cellspacing='0' cellpadding='0' align='center' bgcolor=#eeeeee border='0'>
  <tr>
    <td valign=middle align='center'> <i><b><font color="#999999"> www.dcopelli.it</font></b></i></td>
</tr>
</table><br>
</BODY></HTML>
