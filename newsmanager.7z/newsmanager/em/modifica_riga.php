<?php
$id = $_GET["id"]; 
$textfile = fopen("db/iscritti.txt", "r");

while ( $rigafile = fgets($textfile,1024)) {
 $campiriga = explode("|", $rigafile);
 $idriga = $campiriga[0];

 if ($idriga == $id) {
  $cid = $campiriga[0];
  $cnome = $campiriga[1];
  $cemail = $campiriga[2];
 }

}
fclose($textfile);
?>
<html>
<head>
<title>News Manager</title>
<style type="text/css"> 
<!--
body {  font-family: Arial, Helvetica, sans-serif; font-size: 13px}

#form {margin:30px auto;  width: 650px;}
-->
</style>
</HEAD>
<body bgcolor="#CCCCCC" text="#000000" topmargin="0">
    <div id="form">
                  <form method="post" action="aggiorna_riga.php" id="form">
                    <div align="center">Id riga
                      <input type="text" size="8" name="id" value="<?=$cid?>">
                      Nome 
                      <input type="text" size="15" name="nome" value="<?=$cnome?>">
                      Email
                      <input type="text" size="20" name="email" value="<?=$cemail?>">
                      <input type="submit" value="Modifica" name="submit">
                    </div>
                  </form>
 </div>

</BODY></HTML>
