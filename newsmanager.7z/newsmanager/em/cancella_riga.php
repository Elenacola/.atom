<?php
$utente = $_GET["id"];
$textfile = fopen("db/iscritti.txt", "r");
$textfile_new = fopen("db/iscritti_new.txt", "a");
 while ($rigafile = fgets($textfile,1024)) {
 $campiriga = explode("|", $rigafile);
 $idriga = $campiriga[0];
 if ($idriga <> $utente) {
  fwrite($textfile_new, $rigafile);
 }
}
fclose($textfile);
fclose($textfile_new);
unlink("db/iscritti.txt");
rename("db/iscritti_new.txt","db/iscritti.txt");
 
?>

<html>
<head>
<title>News Manager</title>
<style type="text/css">
<!--
td {  font-family: Arial, Helvetica, sans-serif; font-size: 13px}
-->
</style>
</HEAD>
<body bgcolor="#CCCCCC" text="#000000" topmargin="0">
<table cellspacing=1 cellpadding=0 width="700" align=center bgcolor=#666666 border=0>
  <tbody> 
  <tr> 
    <td> 
      <table cellspacing=0 cellpadding=4 width="100%" align=center    bgcolor=#ffffff border=0>
        <tbody> 
        <tr> 
          <td bgcolor=#0000FF> 
            <div align="center"><b><font size="6" color="#FFFFFF"><i>News Manager<br>
              <font size="4">Il software per gestire i tuoi iscritti</font></i></font></b></div>
          </td>
        </tr>
        <tr> 
          <td>&nbsp; </td>
        </tr>
        <tr> 
          <td bgcolor="#EAEAEA"> 
            <div align="center"><b><a href="index.htm">Home</a> | <a href="iscrizione.htm" target="_blank">Test 
              modulo Iscrizione</a> | <a href="form_invio.htm">Invia Newsletter</a> 
              | <a href="lista_iscritti.php">Elenco Iscritti</a> | <a href="2806.htm" target="_blank">Help</a></b></div>
          </td>
        </tr>
        <tr> 
          <td> <br>
            <p align=center>Cancellazione eseguita con successo</p><br>
            </td>
        </tr>
        </tbody> 
      </table>
    </td>
  </tr>
  </tbody>
</table>
<table width='700' cellspacing='0' cellpadding='0' align='center' bgcolor=#eeeeee border='0'>
  <tr>
    <td valign=middle align='center'> <i><b><font color="#999999"> www.dcopelli.it</font></b></i></td>
</tr>
</table><br>
</BODY></HTML>
