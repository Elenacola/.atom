<?php
$numrighe = 0;
$textfile = fopen("db/iscritti.txt", "r");
while ( fgets($textfile,1024) ) {
 $campiriga = explode("|", $rigafile);
 $numriga = $campiriga[0];    
}
fclose($textfile);

$textfile = fopen("db/iscritti.txt", "a");
$idriga = $numriga + 1;
$cnome = $_POST["nome"];
$cemail = $_POST["email"];
$datiform = "$idriga|$cnome|$cemail\n";
fwrite($textfile, $datiform);
fclose($textfile); 

echo "Grazie per esserti iscritto alla nostra newsletter";

?>