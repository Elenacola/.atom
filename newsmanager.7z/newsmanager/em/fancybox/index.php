<?php
Header("Location: http://www.video-corsi.com");
?>